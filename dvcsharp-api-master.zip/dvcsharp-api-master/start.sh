#!/bin/bash

dotnet ef database update
dotnet watch run


